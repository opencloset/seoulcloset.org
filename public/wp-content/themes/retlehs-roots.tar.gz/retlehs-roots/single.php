<div class="story_sub_info">
	<img src="/assets/img/story_info_text.png"/>
</div>

<div class="wrap container" role="document">
  <div class="content row">

    <div class="main <?php echo roots_main_class(); ?>" role="main">
      <hr class='dot'>
      <?php get_template_part('templates/content', 'single'); ?>
    </div><!-- /.main -->
    <?php if (roots_display_sidebar()) : ?>
    <aside class="sidebar <?php echo roots_sidebar_class(); ?>" role="complementary">
      <hr class='dot'>
      <?php include roots_sidebar_path(); ?>
    </aside><!-- /.sidebar -->
    <?php endif; ?>
  </div><!-- /.content -->
</div><!-- /.wrap -->