<?php
/**
 * Custom functions
 */
