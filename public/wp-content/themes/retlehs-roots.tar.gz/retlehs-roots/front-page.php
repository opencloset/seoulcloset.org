<div class="banner visible-desktop">
	<div class="banner_container">
		<div class="closeticon">
			<div class="closeticon_closet">
				<img src="assets/img/index_closeticon.png" alt="index_closeticon"/>
			</div> 
			<div class="closeticon_list">
	      <div id="myCarousel" class="carousel slide">
	        <ol class="carousel-indicators">
	          <li class="cloth_1 active" data-target="#myCarousel" data-slide-to="0" class="active"></li>
	          <li class="cloth_2" data-target="#myCarousel" data-slide-to="1"></li>
	          <li class="cloth_3" data-target="#myCarousel" data-slide-to="2"></li>
	          <li class="cloth_4" data-target="#myCarousel" data-slide-to="3"></li>
	          <li class="cloth_5" data-target="#myCarousel" data-slide-to="4"></li>
	          <li class="cloth_6" data-target="#myCarousel" data-slide-to="5"></li>
	        </ol>
	        
	        
	        <!-- Carousel items -->
	        <div class="carousel-inner">
	          <div class="active item">6월 말 이사를 하는데 짐도 줄이고 
	      안 입는 옷도 정리할 좋은 기회라 옷장정리 신청을 
	      결심했습니다. 서울시민 열린옷장 화이팅! <br> -마포구 양모모양</div>
	          <div class="item">6월 말 이사를 하는데 짐도 줄이고 
	      안 입는 옷도 정리할 좋은 기회라 옷장정리 신청을 
	      결심했습니다. 서울시민 열린옷장 화이팅! <br> -마포구 양모모양</div>
	          <div class="item">6월 말 이사를 하는데 짐도 줄이고 
	      안 입는 옷도 정리할 좋은 기회라 옷장정리 신청을 
	      결심했습니다. 서울시민 열린옷장 화이팅! <br> -마포구 양모모양</div>
	          <div class="item">6월 말 이사를 하는데 짐도 줄이고 
	      안 입는 옷도 정리할 좋은 기회라 옷장정리 신청을 
	      결심했습니다. 서울시민 열린옷장 화이팅! <br> -마포구 양모모양</div>
	          <div class="item">6월 말 이사를 하는데 짐도 줄이고 
	      안 입는 옷도 정리할 좋은 기회라 옷장정리 신청을 
	      결심했습니다. 서울시민 열린옷장 화이팅! <br> -마포구 양모모양</div>
	          <div class="item">6월 말 이사를 하는데 짐도 줄이고 
	      안 입는 옷도 정리할 좋은 기회라 옷장정리 신청을 
	      결심했습니다. 서울시민 열린옷장 화이팅! <br> -마포구 양모모양</div>
	        </div>
	        <a class="carousel-control left" href="#myCarousel" data-slide="prev"><img src="assets/img/index_banner_prev.png"></a>
	        <a class="carousel-control right" href="#myCarousel" data-slide="next"><img src="assets/img/index_banner_next.png"></a>
	      </div>  		
	    </div>
	  </div>
	</div>
</div>
	

		
<div class="index">	
	<div class="wrapp">
		<div class="container">
			<div class="step row">
			 <!-- <span> 열린옷장 신청 단계 </span> -->
			  <div class="span12 line">
			  	<div class="row-fluid">
			  		<div class="span4 step">
					  	<img src="assets/img/intro_step1.png" alt="step"/>
			  		</div>
			  		<div class="span4 step">
					  	<img src="assets/img/intro_step2.png" alt="step"/>
			  		</div>
			  		<div class="span4 step">
					  	<img src="assets/img/intro_step3.png" alt="step"/>
			  		</div>
			  	</div>
			  </div>
			</div><!-- step -->

		  <div class="row apply">
		  	<div class="span7">
					당신의 옷장은 안녕하신가요? 지금 옷장정리를 신청하세요!
		  	</div>
		  	<div class="span5">
					<a class="btn btn-large btn-warning btn-block btn_apply" type="button" href="http://seoulcloset.org/apply/"><b><i class="icon-check icon-white">
					</i>&nbsp;신 청 하 기</b></a>
		  	</div>
		  </div>
			
			<div class="stories row">
			  <?php 
			  
			  query_posts('posts_per_page=3');
			  
			  while (have_posts()) : the_post(); ?>
  				<div class="span3 box">
  				  <div class='box'>
              <?php the_post_thumbnail('thumbnail') ?>
              <div class='interview'>
                <a href='<?php the_permalink(); ?>'>
                  <img src="/assets/img/icon_hanger.png">
                  <p><?php the_field("interview");  ?></p>
                  <span>READ MORE</span>
                </a>
              </div>
  				  </div>
  				</div>
				<?php endwhile; ?>
				<div class="span3 more">
					<a href="http://seoulcloset.org/category/stories/">VIEW MORE STORIES &gt;</a>
				</div>
			</div>
				
			<div class='partners'>
				<img src="assets/img/partner.png" alt="partner" width="940" height="35">
			</div>	
		</div> <!-- end. container -->
	</div> <!-- end. wrapp -->
</div> <!-- end. index -->

