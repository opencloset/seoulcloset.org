<div class="apply_banner">
	<img src="/assets/img/story_info_text.png" alt="story_info_text"/>
</div>


<div class="apply">
	<div class="wrapp">
		<div class="container">
  		<iframe src="https://docs.google.com/forms/d/1Vjgd9qCZVRId4ATBMX6cYL2M-Vlx6btmkPX6tzLAAPo/viewform?embedded=true" width="1000" height="2000" frameborder="0" marginheight="0" marginwidth="0">로드 중...</iframe>
		</div> <!-- end. container -->
	</div> <!-- end. wrapp -->
</div> <!-- end. apply -->