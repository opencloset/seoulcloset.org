<footer class="content-info" role="contentinfo">
  <div class="container">
  	<img src="/assets/img/footer_icon.png" alt="footer_icon"/>
  	<div class="footer_text">
	    서울특별시 광진구 화양동 48-3 웅진빌딩 403호 열린옷장, 우) 143-917 T) 070-7583-7521, email : share@theopencloset.net<p>
	    서울특별시 비영리민간단체 제1508호 / 서울특별시 공유단체 지정 제26호  * 고유번호 206-80-16607 <p>
	    © 2013 Seoulcloset.Org 서울시민 열린옷장 All Rights Reserved.<p>
	</div>
  </div>
</footer>

<?php wp_footer(); ?>
