<div class="story_info">
	<img src="/assets/img/story_info_text.png"/>
</div>
<div class="wrap container" role="document">
  <div class="content">
    <div class="main <?php echo roots_main_class(); ?>" role="main">      
		  <div class="story">
				<div class="wrapp">
					<div class="container" style='margin-left:-10px;'>
            <div class="row box_container">
              <?php 
              $grids = array(
                'span6 left photo_left', 'span3', 
                'span3 offset3 left', 'span3', 'span3', 
                'span3 left', 'span3 left', 'span6 photo_left', 
                'span6 left photo_right', 'span3', 'span3',
              );
              $count = 0;
              while (have_posts()) : the_post(); ?>
                <div class="box <?php echo $grids[$count%sizeof($grids)] ?>">
                  <?php the_post_thumbnail('thumbnail') ?>
                  <div class='interview'>
                    <a href='<?php the_permalink(); ?>'>
                      <img src="/assets/img/icon_hanger.png">
                      <p><?php the_field("interview");  ?></p>
                      <span>READ MORE</span>
                    </a>
                  </div>
                  <div class='location'>
                    <a href='<?php the_permalink(); ?>'>
                      <img src="/assets/img/icon_magnifier.png">
                      <p><?php the_field('location'); ?></p>
                      <span>READ MORE</span>
                    </a>
                  </div>
                </div>
              <?php $count++; endwhile; ?>
            </div>
			
            <!--
            <?php if ($wp_query->max_num_pages > 1) : ?>
              <nav class="post-nav">
                <ul class="pager">
                  <li class="previous"><?php next_posts_link(__('&larr; Older posts', 'roots')); ?></li>
                  <li class="next"><?php previous_posts_link(__('Newer posts &rarr;', 'roots')); ?></li>
                </ul>
              </nav>
            <?php endif; ?>
            -->					
					</div> <!-- container -->
				</div> <!-- wrapp -->
			</div> <!-- story -->
    </div><!-- /.main -->
  </div><!-- /.content -->
</div><!-- /.wrap -->